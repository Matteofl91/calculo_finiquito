import CalculadoraVacaciones from '@/components/CalculadoraVacaciones';

const Index = () => {
  return <CalculadoraVacaciones />;
};

export default Index;