import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Trash2, Plus, Calculator } from 'lucide-react';

interface Periodo {
  id: number;
  entrada: string;
  salida: string;
}

interface Resultados {
  diasLaborablesTotales: number;
  diasNaturalesTotales: number;
  vacacionesGeneradas: number;
  vacacionesDisfrutadas: number;
  vacacionesRestantes: number;
  descanso8h: number;
  descanso12h: number;
  descansoTotal: number;
  descansoRestante: number;
}

const CalculadoraVacaciones: React.FC = () => {
  const [periodos, setPeriodos] = useState<Periodo[]>([]);
  const [dias8h, setDias8h] = useState<number>(0);
  const [dias12h, setDias12h] = useState<number>(0);
  const [vacacionesDisfrutadas, setVacacionesDisfrutadas] = useState<number>(0);
  const [turnoDisfrutado, setTurnoDisfrutado] = useState<number>(0);
  const [resultados, setResultados] = useState<Resultados | null>(null);

  // Cargar datos del localStorage al inicializar
  useEffect(() => {
    const datosGuardados = localStorage.getItem('calculadoraVacaciones');
    if (datosGuardados) {
      try {
        const datos = JSON.parse(datosGuardados);
        setPeriodos(datos.periodos || []);
        setDias8h(datos.dias8h || 0);
        setDias12h(datos.dias12h || 0);
        setVacacionesDisfrutadas(datos.vacacionesDisfrutadas || 0);
        setTurnoDisfrutado(datos.turnoDisfrutado || 0);
      } catch (error) {
        console.error('Error al cargar datos:', error);
      }
    }
    
    // Si no hay períodos, agregar uno por defecto
    if (periodos.length === 0) {
      agregarPeriodo();
    }
  }, []);

  // Guardar datos en localStorage cuando cambien
  useEffect(() => {
    const datos = {
      periodos,
      dias8h,
      dias12h,
      vacacionesDisfrutadas,
      turnoDisfrutado
    };
    localStorage.setItem('calculadoraVacaciones', JSON.stringify(datos));
  }, [periodos, dias8h, dias12h, vacacionesDisfrutadas, turnoDisfrutado]);

  const agregarPeriodo = () => {
    const nuevoPeriodo: Periodo = {
      id: Date.now(),
      entrada: '',
      salida: ''
    };
    setPeriodos([...periodos, nuevoPeriodo]);
  };

  const eliminarPeriodo = (id: number) => {
    setPeriodos(periodos.filter(p => p.id !== id));
  };

  const actualizarPeriodo = (id: number, campo: 'entrada' | 'salida', valor: string) => {
    setPeriodos(periodos.map(p => 
      p.id === id ? { ...p, [campo]: valor } : p
    ));
  };

  // Función para calcular los DÍAS LABORABLES (L-V)
  const calcularDiasLaborables = (fechaInicio: Date, fechaFin: Date): number => {
    let dias = 0;
    let fecha = new Date(fechaInicio.getTime());
    const fin = new Date(fechaFin.getTime());

    while (fecha <= fin) {
      const diaSemana = fecha.getDay();
      // 0 = Domingo, 6 = Sábado. Contamos solo si no es Sábado ni Domingo.
      if (diaSemana !== 0 && diaSemana !== 6) {
        dias++;
      }
      fecha.setDate(fecha.getDate() + 1);
    }
    return dias;
  };

  // Función para calcular los DÍAS NATURALES
  const calcularDiasNaturales = (fechaInicio: Date, fechaFin: Date): number => {
    // Diferencia en milisegundos
    const diffTime = Math.abs(fechaFin.getTime() - fechaInicio.getTime());
    // Conversión de milisegundos a días (1000ms * 60s * 60min * 24h)
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    // Se añade 1 para incluir el día de inicio y el de fin
    return diffDays + 1;
  };

  const calcular = () => {
    let diasLaborablesTotales = 0;
    let diasNaturalesTotales = 0;

    for (const periodo of periodos) {
      if (periodo.entrada && periodo.salida) {
        // Se añade 'T00:00:00' para asegurar que la fecha sea interpretada correctamente
        const entrada = new Date(periodo.entrada + 'T00:00:00');
        const salida = new Date(periodo.salida + 'T00:00:00');

        if (salida >= entrada) {
          diasLaborablesTotales += calcularDiasLaborables(entrada, salida);
          diasNaturalesTotales += calcularDiasNaturales(entrada, salida);
        }
      }
    }

    // FÓRMULA CORREGIDA (Base: Días Naturales Trabajados / 365 * 23)
    const vacacionesGeneradas = (diasNaturalesTotales / 365) * 23;

    // Cálculos de descansos
    const descanso8h = dias8h * 1;
    const descanso12h = dias12h * 1.5;
    const descansoTotal = descanso8h + descanso12h;

    const vacacionesRestantes = vacacionesGeneradas - vacacionesDisfrutadas;
    const descansoRestante = descansoTotal - turnoDisfrutado;

    setResultados({
      diasLaborablesTotales,
      diasNaturalesTotales,
      vacacionesGeneradas,
      vacacionesDisfrutadas,
      vacacionesRestantes,
      descanso8h,
      descanso12h,
      descansoTotal,
      descansoRestante
    });
  };

  return (
    <div className="min-h-screen p-4 md:p-6 lg:p-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-2xl shadow-2xl p-6 md:p-8">
          {/* Header con logo y título futurista */}
          <div className="glass-header rounded-2xl p-6 mb-8">
            <div className="flex flex-col md:flex-row items-center justify-center gap-6">
              <div className="logo-container floating-logo">
                <img 
                  src="./images/csif_logo.jpg" 
                  alt="CSIF Logo" 
                  className="h-16 md:h-20 w-auto object-contain"
                />
              </div>
              <div className="text-center md:text-left">
                <h1 className="futuristic-title text-3xl md:text-4xl lg:text-5xl font-black tracking-tight leading-tight">
                  CALCULADORA DE FINIQUITOS
                </h1>
                <p className="text-lg md:text-xl font-semibold text-green-100 mt-2 tracking-wide">
                  Vacaciones / 4º Turnos 2025
                </p>
                <div className="flex items-center justify-center md:justify-start gap-2 mt-3">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                  <span className="text-sm text-green-200 font-medium">Sistema Avanzado de Cálculo</span>
                </div>
              </div>
            </div>
          </div>

          {/* Períodos de Trabajo */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-lg md:text-xl text-primary border-b-2 border-primary pb-2">
                Períodos de Trabajo
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {periodos.map((periodo) => (
                <div key={periodo.id} className="bg-muted p-4 rounded-lg">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-end">
                    <div>
                      <Label htmlFor={`entrada-${periodo.id}`} className="text-sm font-medium">
                        Fecha entrada:
                      </Label>
                      <Input
                        id={`entrada-${periodo.id}`}
                        type="date"
                        value={periodo.entrada}
                        onChange={(e) => actualizarPeriodo(periodo.id, 'entrada', e.target.value)}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <Label htmlFor={`salida-${periodo.id}`} className="text-sm font-medium">
                        Fecha salida:
                      </Label>
                      <Input
                        id={`salida-${periodo.id}`}
                        type="date"
                        value={periodo.salida}
                        onChange={(e) => actualizarPeriodo(periodo.id, 'salida', e.target.value)}
                        className="mt-1"
                      />
                    </div>
                    <div className="md:col-span-2 flex justify-end">
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => eliminarPeriodo(periodo.id)}
                        className="flex items-center gap-2"
                      >
                        <Trash2 className="h-4 w-4" />
                        Eliminar
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
              <Button onClick={agregarPeriodo} className="w-full md:w-auto flex items-center gap-2">
                <Plus className="h-4 w-4" />
                Agregar Período
              </Button>
            </CardContent>
          </Card>

          {/* Días de 4º Turno */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-lg md:text-xl text-primary border-b-2 border-primary pb-2">
                Días de 4º Turno Trabajados
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-muted p-4 rounded-lg">
                  <h3 className="text-primary font-semibold mb-3">Turnos de 8 horas</h3>
                  <Label htmlFor="dias8h" className="text-sm font-medium">
                    Días trabajados:
                  </Label>
                  <Input
                    id="dias8h"
                    type="number"
                    min="0"
                    value={dias8h}
                    onChange={(e) => setDias8h(Number(e.target.value) || 0)}
                    className="mt-1"
                  />
                </div>
                <div className="bg-muted p-4 rounded-lg">
                  <h3 className="text-primary font-semibold mb-3">Turnos de 12 horas</h3>
                  <Label htmlFor="dias12h" className="text-sm font-medium">
                    Días trabajados:
                  </Label>
                  <Input
                    id="dias12h"
                    type="number"
                    min="0"
                    value={dias12h}
                    onChange={(e) => setDias12h(Number(e.target.value) || 0)}
                    className="mt-1"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Días Disfrutados */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="text-lg md:text-xl text-primary border-b-2 border-primary pb-2">
                Días Disfrutados
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="vacacionesDisfrutadas" className="text-sm font-medium">
                  Días de vacaciones disfrutados:
                </Label>
                <Input
                  id="vacacionesDisfrutadas"
                  type="number"
                  min="0"
                  value={vacacionesDisfrutadas}
                  onChange={(e) => setVacacionesDisfrutadas(Number(e.target.value) || 0)}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="turnoDisfrutado" className="text-sm font-medium">
                  Días de 4º turno disfrutados:
                </Label>
                <Input
                  id="turnoDisfrutado"
                  type="number"
                  min="0"
                  value={turnoDisfrutado}
                  onChange={(e) => setTurnoDisfrutado(Number(e.target.value) || 0)}
                  className="mt-1"
                />
              </div>
            </CardContent>
          </Card>

          {/* Botón Calcular */}
          <Button 
            onClick={calcular} 
            className="w-full py-4 text-lg font-semibold bg-gradient-to-r from-primary to-green-700 hover:from-primary/90 hover:to-green-700/90 flex items-center justify-center gap-2"
          >
            <Calculator className="h-5 w-5" />
            Calcular
          </Button>

          {/* Resultados */}
          {resultados && (
            <Card className="mt-8 bg-green-50 border-green-200">
              <CardHeader>
                <CardTitle className="text-xl text-green-800">Resultados</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center p-3 bg-white rounded-lg border-l-4 border-primary">
                  <span className="font-semibold text-gray-700">Días laborables (L-V) trabajados:</span>
                  <span className="font-bold text-primary">{resultados.diasLaborablesTotales}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-white rounded-lg border-l-4 border-primary">
                  <span className="font-semibold text-gray-700">Días naturales trabajados (Base para Vac.):</span>
                  <span className="font-bold text-primary">{resultados.diasNaturalesTotales}</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-white rounded-lg border-l-4 border-green-500">
                  <span className="font-semibold text-gray-700">Vacaciones generadas (Base 23 días háb.):</span>
                  <span className="font-extrabold text-green-700">{resultados.vacacionesGeneradas.toFixed(2)} días</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-white rounded-lg border-l-4 border-primary">
                  <span className="font-semibold text-gray-700">Vacaciones disfrutadas:</span>
                  <span className="font-bold text-primary">{resultados.vacacionesDisfrutadas.toFixed(2)} días</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-white rounded-lg border-l-4 border-primary">
                  <span className="font-semibold text-gray-700">Vacaciones restantes:</span>
                  <span className={`font-bold ${resultados.vacacionesRestantes >= 0 ? 'text-primary' : 'text-red-600'}`}>
                    {resultados.vacacionesRestantes >= 0 
                      ? `${resultados.vacacionesRestantes.toFixed(2)} días`
                      : `DEBE ${Math.abs(resultados.vacacionesRestantes).toFixed(2)} días`
                    }
                  </span>
                </div>
                <div className="flex justify-between items-center p-3 bg-white rounded-lg border-l-4 border-primary">
                  <span className="font-semibold text-gray-700">Descanso 4º turno generado (8h):</span>
                  <span className="font-bold text-primary">{resultados.descanso8h.toFixed(2)} días</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-white rounded-lg border-l-4 border-primary">
                  <span className="font-semibold text-gray-700">Descanso 4º turno generado (12h):</span>
                  <span className="font-bold text-primary">{resultados.descanso12h.toFixed(2)} días</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-white rounded-lg border-l-4 border-primary">
                  <span className="font-semibold text-gray-700">Descanso total generado:</span>
                  <span className="font-bold text-primary">{resultados.descansoTotal.toFixed(2)} días</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-white rounded-lg border-l-4 border-primary">
                  <span className="font-semibold text-gray-700">Descanso 4º turno restante:</span>
                  <span className={`font-bold ${resultados.descansoRestante >= 0 ? 'text-primary' : 'text-red-600'}`}>
                    {resultados.descansoRestante >= 0 
                      ? `${resultados.descansoRestante.toFixed(2)} días`
                      : `DEBE ${Math.abs(resultados.descansoRestante).toFixed(2)} días`
                    }
                  </span>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
};

export default CalculadoraVacaciones;